# This is a guide for Experiment 18 using Power BI
# Since Power BI is not a Python tool, we will simulate the process here.

# Step 1: Save data to a CSV
import pandas as pd
from sklearn.datasets import load_iris

# Load dataset
iris = load_iris()
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df['target'] = iris.target

# Export to CSV
df.to_csv("iris_data_for_powerbi.csv", index=False)
print("Data exported to iris_data_for_powerbi.csv")

# Step 2 (Manual): Open Power BI Desktop
# Step 3: Click on 'Get Data' > 'Text/CSV' > Load the file
# Step 4: Use Power BI's visualization tools to create reports