import pandas as pd
from sklearn.datasets import load_iris
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

clf = AdaBoostClassifier(n_estimators=50)
clf.fit(X, y)
print("AdaBoost Accuracy:", accuracy_score(y, clf.predict(X)))