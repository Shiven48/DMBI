import pandas as pd
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

clf = RandomForestClassifier()
clf.fit(X, y)
print("Random Forest Accuracy:", accuracy_score(y, clf.predict(X)))