import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

def naive_bayes(X, y):
    df = pd.concat([X, y.rename("class")], axis=1)
    classes = y.unique()
    summaries = {}
    for c in classes:
        df_c = df[df["class"] == c]
        summaries[c] = {
            "prior": len(df_c) / len(df),
            "mean": df_c.mean(),
            "std": df_c.std()
        }
    return summaries

def predict_nb(summaries, row):
    posteriors = {}
    for cls, stats in summaries.items():
        prior = np.log(stats["prior"])
        likelihood = -0.5 * np.sum(np.log(2 * np.pi * stats["std"] ** 2)) - np.sum(
            ((row - stats["mean"]) ** 2) / (2 * stats["std"] ** 2)
        )
        posteriors[cls] = prior + likelihood
    return max(posteriors, key=posteriors.get)

summaries = naive_bayes(X, y)
y_pred_nb = X.apply(lambda row: predict_nb(summaries, row), axis=1)
print("Naive Bayes Accuracy:", accuracy_score(y, y_pred_nb))