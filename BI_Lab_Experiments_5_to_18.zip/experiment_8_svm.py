import pandas as pd
from sklearn.datasets import load_iris
from sklearn import svm
from sklearn.metrics import accuracy_score

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

clf = svm.SVC()
clf.fit(X, y)
print("SVM Accuracy:", accuracy_score(y, clf.predict(X)))