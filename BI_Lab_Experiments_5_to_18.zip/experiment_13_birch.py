import pandas as pd
from sklearn.datasets import load_iris
from sklearn.cluster import Birch
import matplotlib.pyplot as plt

# Load data
iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)

# Apply BIRCH clustering
birch_model = Birch(n_clusters=3)
birch_model.fit(X)

# Cluster labels
labels = birch_model.labels_
centroids = birch_model.subcluster_centers_

# Display results
print("BIRCH labels:", labels)
print("Number of subclusters:", len(centroids))

# Plot clusters
plt.scatter(X.iloc[:, 0], X.iloc[:, 1], c=labels, cmap='viridis', label='Points')
plt.scatter(centroids[:, 0], centroids[:, 1], s=200, c='red', marker='X', label='Centroids')
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("BIRCH Clustering")
plt.legend()
plt.show()