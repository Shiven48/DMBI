import pandas as pd
from sklearn.datasets import load_iris
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.Series(iris.target)

clf = MLPClassifier(hidden_layer_sizes=(10,), max_iter=500)
clf.fit(X, y)
print("MLP Accuracy:", accuracy_score(y, clf.predict(X)))