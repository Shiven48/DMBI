import pandas as pd
from mlxtend.frequent_patterns import fpgrowth, association_rules

# Sample dataset
dataset = [
    ['milk', 'bread', 'butter'],
    ['bread', 'butter'],
    ['milk', 'bread'],
    ['milk', 'bread', 'butter'],
    ['bread'],
]

# Convert dataset to one-hot encoded dataframe
from mlxtend.preprocessing import TransactionEncoder
te = TransactionEncoder()
te_array = te.fit(dataset).transform(dataset)
df = pd.DataFrame(te_array, columns=te.columns_)

# Apply FP-Growth
frequent_itemsets = fpgrowth(df, min_support=0.5, use_colnames=True)
print("Frequent Itemsets using FP-Growth:
", frequent_itemsets)

# Generate association rules
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)
print("
Association Rules:
", rules)